package com.cst3115.enterprise.assignment3

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.cst3115.enterprise.assignment3.ui.theme.Assignment3Theme
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class MainActivity : ComponentActivity() {
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Assignment3Theme {

                val tasks = mutableListOf(
                    Task("Ottawa", "110 Laurier Ave W", "Fix air conditioning", 45.421016F, -75.690018F),
                    Task("Cornwall", "360 Pitt St", "Install new faucet", 45.021201F, -74.730341F),
                    Task("Toronto", "100 Queen St W", "Electrical maintenance", 43.651670F, -79.382953F)
                )

                fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

                val context = LocalContext.current

                val navController = rememberNavController()

                var startDestination = "loginActivity"
                if (getLoginState(context)) {
                    startDestination = "menuActivity"
                }

                NavHost(navController = navController, startDestination = startDestination) {
                    composable("loginActivity") {
                        LoginActivity(navController = navController)
                    }
                    composable("menuActivity") {
                        MenuActivity(navController = navController, fusedLocationClient = fusedLocationClient)
                    }
                    // ---------- main requirements ----------
                    composable("taskList") {
                        TaskList(navController = navController, tasks)
                    }
                    composable("staticMap") {
                        StaticMap(navController = navController)
                    }
                }

            }
        }
    }
}

fun getLoginState(context: Context): Boolean {
    val sharedPreferences = context.getSharedPreferences("TechFixPrefs", Context.MODE_PRIVATE)
    return sharedPreferences.getBoolean("isLoggedIn", false)
}