package com.cst3115.enterprise.assignment3
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberImagePainter
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberPermissionState

@Composable
fun StaticMap(navController: NavController) {

    val context = LocalContext.current

    val clientLat = getLat(context)
    val clientLng = getLng(context)
    val clientName = getName(context)

    val apiKey = "AIzaSyD7uHmHXp5jwbWn06aTOrMUAY4quLoZWHg"

    // Create static map URL
    val staticMapUrl = "https://maps.googleapis.com/maps/api/staticmap?center=$clientLat,$clientLng" +
            "&zoom=14&size=600x300&markers=color:red|label:${clientName.first()}|$clientLat,$clientLng" +
            "&key=" + apiKey

    val imagePainter: Painter = rememberImagePainter(staticMapUrl)

    Column(modifier = Modifier.padding(16.dp)) {
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Text("Static Map for " + clientName, style = MaterialTheme.typography.headlineSmall)
        }
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Image(
                painter = imagePainter,
                contentDescription = "Client Map",
                modifier = Modifier.padding(top = 16.dp).size(300.dp)
            )
        }
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = {
                navController.navigate("menuActivity")
            }) { Text("Back") }
        }
    }
}

fun getLat(context: Context): Float {
    val sharedPreferences = context.getSharedPreferences("TechFixPrefs", Context.MODE_PRIVATE)
    return sharedPreferences.getFloat("clientLat", 0.0F)
}

fun getLng(context: Context): Float {
    val sharedPreferences = context.getSharedPreferences("TechFixPrefs", Context.MODE_PRIVATE)
    return sharedPreferences.getFloat("clientLng", 0.0F)
}

fun getName(context: Context): String {
    val sharedPreferences = context.getSharedPreferences("TechFixPrefs", Context.MODE_PRIVATE)
    return sharedPreferences.getString("clientName", "Failed to load save")!!
}