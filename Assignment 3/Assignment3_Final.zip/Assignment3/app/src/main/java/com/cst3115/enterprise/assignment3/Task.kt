package com.cst3115.enterprise.assignment3
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

data class Task(val clientName: String, val address: String, val jobDescription: String, val clientLat: Float, val clientLng: Float)

@Composable
fun TaskList(navController: NavController, tasks: MutableList<Task>) {
    Column(modifier = Modifier.padding(16.dp)) {
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Text("TechFix - Tasks", style = MaterialTheme.typography.headlineSmall)
            Button(onClick = {
                navController.navigate("menuActivity")
            }) { Text("Back") }
        }

        tasks.forEach { task ->
            TaskItem(navController = navController, task = task, tasks = tasks)
        }

    }
}

@Composable
fun TaskItem(navController: NavController, task: Task, tasks: MutableList<Task>) {

    val context = LocalContext.current

    Card(modifier = Modifier.padding(bottom = 4.dp)) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(text = "Client: ${task.clientName}")
            Text(text = "Address: ${task.address}")
            Text(text = "Job: ${task.jobDescription}")
            Button(modifier = Modifier.padding(top = 4.dp), onClick ={
                tasks.remove(task)
                navController.navigate("taskList")
            }) {
                Text("Mark as Complete")
            }
            Button(modifier = Modifier.padding(top = 4.dp), onClick ={
                saveCoords(context, task)
                navController.navigate("staticMap")
            }) {
                Text("View Location")
            }
        }
    }
}

fun saveCoords(context: Context, task: Task) {
    val sharedPreferences = context.getSharedPreferences("TechFixPrefs", Context.MODE_PRIVATE)
    with(sharedPreferences.edit()) {
        putFloat("clientLat", task.clientLat)
        putFloat("clientLng", task.clientLng)
        putString("clientName", task.clientName)
        apply()
    }
}