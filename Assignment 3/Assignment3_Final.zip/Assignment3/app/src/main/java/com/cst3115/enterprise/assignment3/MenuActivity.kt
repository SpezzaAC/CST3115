package com.cst3115.enterprise.assignment3

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.navigation.NavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.tasks.Task

@Composable
fun MenuActivity(navController: NavController, fusedLocationClient: FusedLocationProviderClient) {

    val context = LocalContext.current

    var isLoading by remember { mutableStateOf(false) }
    var permissionGranted by remember { mutableStateOf(false) }

    // Request location permission at runtime
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            permissionGranted = granted
        }
    )

    LaunchedEffect(Unit) {
        // Check for permission when the screen is first launched
        when {
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED -> {
                permissionGranted = true
            }
            else -> {
                permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
    }

    Column(modifier = Modifier.padding(25.dp)) {
        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly) {
            Text("TechFix - Main Menu", style = MaterialTheme.typography.headlineSmall)
        }
        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = {
                navController.navigate("taskList")
            }) { Text("Task List") }
        }
        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = {
                if (permissionGranted) {
                    fetchCurrentLocation(fusedLocationClient, context, navController) {}
                }
            }) { Text("Current Location") }
        }
        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = {
                logout(context)
                navController.navigate("loginActivity")
            }) { Text("Logout") }
        }
    }

}

fun logout(context: Context) {
    val sharedPreferences = context.getSharedPreferences("TechFixPrefs", Context.MODE_PRIVATE)
    with(sharedPreferences.edit()) {
        putBoolean("isLoggedIn", false)
        apply()
    }
}

@SuppressLint("MissingPermission")
fun fetchCurrentLocation(
    fusedLocationClient: FusedLocationProviderClient,
    context: Context,
    navController: NavController,
    onLocationReceived: (String) -> Unit
) {
    val locationTask: Task<android.location.Location> = fusedLocationClient.lastLocation

    locationTask.addOnSuccessListener { location ->
        if (location != null) {
            saveCurrentCoords(context, location.latitude.toFloat(), location.longitude.toFloat())
            navController.navigate("staticMap")
        }
    }
    locationTask.addOnFailureListener {
        Log.d("CurrentLocation", "Failed to get location.")
    }
}

fun saveCurrentCoords(context: Context, lat: Float, lng: Float) {
    val sharedPreferences = context.getSharedPreferences("TechFixPrefs", Context.MODE_PRIVATE)
    with(sharedPreferences.edit()) {
        putFloat("clientLat", lat)
        putFloat("clientLng", lng)
        putString("clientName", "Current Location")
        apply()
    }
}