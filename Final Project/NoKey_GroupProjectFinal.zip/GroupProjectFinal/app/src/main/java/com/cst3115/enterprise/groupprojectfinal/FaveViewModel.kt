package com.cst3115.enterprise.groupprojectfinal

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class FaveViewModel(application: Application) : AndroidViewModel(application) {

    private val faveDao: FaveDao
    private val database: AppDatabase = AppDatabase.getDatabase(application)

    init {
        faveDao = database.faveDao()
    }

    fun fetchData(faves: MutableList<Fave>) {
        // Launch coroutine in the ViewModel
        viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                val f = faveDao.getAllFaves()
                faves.addAll(f)

                faves.clear()
                faves.addAll(f)

                delay(1000)
            }
        }
    }

    fun pushData(namePrice: String, img: Int){
        viewModelScope.launch(Dispatchers.IO) {
            val newFave = Fave(namePrice = namePrice, img = img)
            faveDao.insertFave(newFave)
        }
    }

    fun delData(fave: Fave){
        viewModelScope.launch(Dispatchers.IO) {
            faveDao.deleteFave(fave)
        }
    }

}