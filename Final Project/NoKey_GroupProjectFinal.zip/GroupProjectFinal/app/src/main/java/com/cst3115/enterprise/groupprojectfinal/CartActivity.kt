package com.cst3115.enterprise.groupprojectfinal

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberImagePainter

@Composable
fun CartActivity(navController: NavController, inCart: MutableList<Array<Int>>) {

    val itemImg = arrayOf(
        arrayOf(R.mipmap.guccibp_foreground, R.mipmap.guccishoe_foreground, R.mipmap.gucciwallet_foreground),
        arrayOf(R.mipmap.hermesbag_foreground, R.mipmap.hermessandal_foreground, R.mipmap.hermeswatch_foreground),
        arrayOf(R.mipmap.lvbackpack_foreground, R.mipmap.lvsneaker_foreground, R.mipmap.lvsuit_foreground),
        arrayOf(R.mipmap.pradajacket_foreground, R.mipmap.pradaloafers_foreground, R.mipmap.pradasuit_foreground),
        arrayOf(R.mipmap.yslbag_foreground, R.mipmap.yslshoes_foreground, R.mipmap.ysltux_foreground)
    )

    val itemName = arrayOf(
        arrayOf("Gucci Bag - $3,705", "Gucci Shoes - $1,485", "Gucci Wallet - $630"),
        arrayOf("Hermes Bag - $29,995", "Hermes Sandals - $1,095", "Hermes Watch - $850"),
        arrayOf("LV Backpack - $5,200", "LV Sneakers - $7,150", "LV Travel Bag - $4,800"),
        arrayOf("Prada Jacket - $8,900", "Prada Loafers - $1,590", "Prada Suit - $5,000"),
        arrayOf("YSL Bag - $1,425", "YSL Shoes - $3,760", "YSL Tuxedo - $4,275")
    )

    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(32.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp)
        ) {
            // Top Bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    modifier = Modifier
                        .size(24.dp)
                        .clickable { navController.navigate("brandActivity") }
                )

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "My Cart",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
            }

            // Cart Items List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(inCart.count()) { index ->
                    CartItemCard(
                        name = itemName[inCart[index][0]][inCart[index][1]],
                        img = itemImg[inCart[index][0]][inCart[index][1]],
                        onRemoveClick = {
                            inCart.removeAt(index)
                            Toast.makeText(
                                context,
                                "Item Removed",
                                Toast.LENGTH_SHORT
                            ).show()
                            navController.navigate("cartActivity")
                        }
                    )
                }
            }
        }

        // Button
        Button(
            onClick = {
                inCart.clear()
                navController.navigate("checkoutActivity")
              },
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(16.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            )
        ) {
            Text(text = "Checkout", style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
fun CartItemCard(name: String, img: Int, onRemoveClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // For images
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .background(Color.White)
            ) {
                Image(
                    painter = rememberImagePainter(
                        data = img
                    ),
                    contentDescription = "",
                    contentScale = ContentScale.FillBounds, // or some other scale
                    modifier = Modifier.matchParentSize()
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Item Details
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.bodyLarge
                )
                Text(
                    text = "", // Enter Price
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Remove Button
            Button(
                onClick = { onRemoveClick() },
                modifier = Modifier.padding(start = 8.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Black,
                    contentColor = Color.White
                )
            ) {
                Text(text = "Remove")
            }
        }
    }
}