package com.cst3115.enterprise.groupprojectfinal

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberImagePainter

@Composable
fun MapActivity(navController: NavController) {

    val context = LocalContext.current

    val clientLat = 45.426090
    val clientLng = -75.691952
    val locationName = "CF Rideau Centre"

    // Insert your api key for the static map feature to work properly
    val apiKey = "API_Key"

    // Create static map URL
    val staticMapUrl = "https://maps.googleapis.com/maps/api/staticmap?center=$clientLat,$clientLng" +
            "&zoom=14&size=600x300&markers=color:red|label:${locationName.first()}|$clientLat,$clientLng" +
            "&key=" + apiKey

    val imagePainter: Painter = rememberImagePainter(staticMapUrl)

    Column(modifier = Modifier.padding(16.dp)) {
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Text(
                text = locationName, style = MaterialTheme.typography.headlineSmall,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
        }
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Image(
                painter = imagePainter,
                contentDescription = "Client Map",
                modifier = Modifier.padding(top = 16.dp).size(300.dp)
            )
        }
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = {
                navController.navigate("brandActivity")
            }) { Text("Return to Brand List") }
        }
    }
}