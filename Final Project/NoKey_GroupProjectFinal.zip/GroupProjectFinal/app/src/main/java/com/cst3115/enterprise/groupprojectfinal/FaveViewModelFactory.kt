package com.cst3115.enterprise.groupprojectfinal

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

// ViewModel Factory
class FaveViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FaveViewModel::class.java)) {
            return FaveViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}