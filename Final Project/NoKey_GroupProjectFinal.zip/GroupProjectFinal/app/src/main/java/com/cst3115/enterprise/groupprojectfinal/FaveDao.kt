package com.cst3115.enterprise.groupprojectfinal

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface FaveDao {

    @Query("SELECT * FROM faves")
    fun getAllFaves(): List<Fave>
    @Insert
    fun insertFave(fave: Fave)
    @Update
    fun updateFave(fave: Fave)
    @Delete
    fun deleteFave(fave: Fave)

}