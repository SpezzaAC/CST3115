package com.cst3115.enterprise.groupprojectfinal

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.compose.ui.platform.LocalContext
import coil.compose.rememberImagePainter

@Composable
fun DetailsActivity(navController: NavController, currentSelection: MutableList<Int>, inCart: MutableList<Array<Int>>, faveViewModel: FaveViewModel) {

    val itemImg = arrayOf(
        arrayOf(R.mipmap.guccibp_foreground, R.mipmap.guccishoe_foreground, R.mipmap.gucciwallet_foreground),
        arrayOf(R.mipmap.hermesbag_foreground, R.mipmap.hermessandal_foreground, R.mipmap.hermeswatch_foreground),
        arrayOf(R.mipmap.lvbackpack_foreground, R.mipmap.lvsneaker_foreground, R.mipmap.lvsuit_foreground),
        arrayOf(R.mipmap.pradajacket_foreground, R.mipmap.pradaloafers_foreground, R.mipmap.pradasuit_foreground),
        arrayOf(R.mipmap.yslbag_foreground, R.mipmap.yslshoes_foreground, R.mipmap.ysltux_foreground)
    )

    val itemName = arrayOf(
        arrayOf("Gucci Bag - $3,705", "Gucci Shoes - $1,485", "Gucci Wallet - $630"),
        arrayOf("Hermes Bag - $29,995", "Hermes Sandals - $1,095", "Hermes Watch - $850"),
        arrayOf("LV Backpack - $5,200", "LV Sneakers - $7,150", "LV Travel Bag - $4,800"),
        arrayOf("Prada Jacket - $8,900", "Prada Loafers - $1,590", "Prada Suit - $5,000"),
        arrayOf("YSL Bag - $1,425", "YSL Shoes - $3,760", "YSL Tuxedo - $4,275")
    )

    val itemDesc = arrayOf(
        arrayOf(
            "This backpack is crafted from the new black GG Monogram coated fabric and features versatile inside pockets and an outside D-ring to attach accessories.",
            "The first sneakers envisioned by Sabato De Sarno for the House, the Re-Web sees Gucci’s heritage stripes as a bold statement detail on a contemporary silhouette. Defined by iconic details, this pair of sneakers is crafted from beige and blue.",
            "A bi-fold wallet, distinguished by our signature Double G hardware. Made in calfskin leather heat-stamped to achieve a boar effect, giving it a textured appearance."
        ),
        arrayOf(
            "This is an authentic HERMES Togo Lizard Kelly Retourne Touch 25 in Vert Rousseau and Vert Cypress. This handbag is handcrafted of dark green calfskin leather.",
            "This is an authentic pair of HERMES Suede Goatskin Womens Chypre Sandals size 39 in Rose Porcelaine.",
            "The watch is crafted of stainless steel and features a white dial, gold hands, gold hour markers, two tone link bracelet, sapphire crystal, and a quartz movement."
        ),
        arrayOf(
            "The spacious Montsouris Backpack is made from Pharrell Williams’ Damier Denim 3D cotton canvas, trimmed with natural leather.",
            "This exceptional interpretation of the LV Skate sneaker is covered in Swarovski™ crystals for a sparkling, all-black look. Inspired by Nineties' skate shoes, this model is characterized by its exaggeranted, padded collar and tongue.",
            "This Horizon 55 rolling suitcase in Monogram Macassar canvas, with touches of vibrant color on the reinforced corners, cane handle, and its compact wheels."
        ),
        arrayOf(
            "This fine cashmere jacket with a sophisticated, classic silhouette and pragmatic character is decorated with the sleek geometric shape of the iconic triangle logo.",
            "The classic, tapered design of these loafers is enhanced by the elegant and distinctive finish of brushed leather, an emblematic material of Prada collections.",
            "Sophisticated tailoring makes this slim-fit single-breasted suit distinctive. The jacket with a two-button closure has classic lapels and a center vent, while the pants feature front slant pockets and back welt pockets."
        ),
        arrayOf(
            "Laced derby shoes with a square toe and stacked heel.",
            "Bag decorated with the cassandre, featuring a leather and chain crossbody strap that can be worn doubled for shoulder carry.",
            "Double-breasted, six-button tuxedo jacket made with certified wool, featuring a satin peaked lapel and satin-covered buttons."
        )
    )

    val context = LocalContext.current // Obtain the context for showing Toast messages

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(32.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Row with Back and Cart Buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                // Back Button
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    modifier = Modifier
                        .size(24.dp)
                        .clickable { navController.navigateUp() }
                )

                Spacer(modifier = Modifier.weight(1f)) // Push Cart button to the right
            }

            Text(
                text = itemName[currentSelection[0]][currentSelection[1]],
                style = MaterialTheme.typography.headlineLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            //Place product image
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .background(Color.White)
                    .padding(16.dp)
            ) {
                Image(
                    painter = rememberImagePainter(
                        data = itemImg[currentSelection[0]][currentSelection[1]]
                    ),
                    contentDescription = "",
                    contentScale = ContentScale.FillBounds, // or some other scale
                    modifier = Modifier.matchParentSize()
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Product Description
            Text(
                text = itemDesc[currentSelection[0]][currentSelection[1]],
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                textAlign = TextAlign.Start
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Add to Cart Button
            Button(
                onClick = {
                    inCart.add(arrayOf(currentSelection[0], currentSelection[1]))

                    Toast.makeText(context, "Item added to Cart", Toast.LENGTH_SHORT).show()

                    navController.navigate("cartActivity")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                )
            ) {
                Text(text = "Add to Cart")
            }

            // Add to Favourites Button
            Button(
                onClick = {
                    faveViewModel.pushData(namePrice = itemName[currentSelection[0]][currentSelection[1]], img = itemImg[currentSelection[0]][currentSelection[1]])
                    Toast.makeText(context, "Item added to Favourites", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                )
            ) {
                Text(text = "Add to Favourites")
            }

            // View Store Location Button
            Button(
                onClick = {
                    navController.navigate("mapActivity")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                )
            ) {
                Text(text = "View Store Location")
            }
        }
    }
}