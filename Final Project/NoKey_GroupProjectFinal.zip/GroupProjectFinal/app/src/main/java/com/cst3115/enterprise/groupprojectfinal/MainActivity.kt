package com.cst3115.enterprise.groupprojectfinal

import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import com.cst3115.enterprise.groupprojectfinal.ui.theme.GroupProjectFinalTheme
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GroupProjectFinalTheme {

                val faves = mutableListOf<Fave>()

                val context = LocalContext.current
                val faveViewModel: FaveViewModel = viewModel(
                    factory = FaveViewModelFactory(context.applicationContext as Application)
                )
                faveViewModel.fetchData(faves)

                val currentSelection = mutableListOf(
                    0,
                    0
                )

                val inCart = mutableListOf<Array<Int>>()

                val navController = rememberNavController()

                NavHost(navController = navController, startDestination = "loginActivity") {
                    composable("loginActivity") {
                        LoginActivity(navController = navController)
                    }
                    composable("brandActivity") {
                        BrandActivity(navController = navController, currentSelection = currentSelection)
                    }
                    composable("itemsActivity") {
                        ItemsActivity(navController = navController, currentSelection = currentSelection)
                    }
                    composable("detailsActivity") {
                        DetailsActivity(navController = navController, currentSelection = currentSelection, inCart = inCart, faveViewModel = faveViewModel)
                    }
                    composable("cartActivity") {
                        CartActivity(navController = navController, inCart = inCart)
                    }
                    composable("faveActivity") {
                        FaveActivity(navController = navController, faves = faves, faveViewModel = faveViewModel)
                    }
                    composable("mapActivity") {
                        MapActivity(navController = navController)
                    }
                    composable("checkoutActivity") {
                        CheckoutActivity(navController = navController)
                    }
                }
            }
        }
    }
}