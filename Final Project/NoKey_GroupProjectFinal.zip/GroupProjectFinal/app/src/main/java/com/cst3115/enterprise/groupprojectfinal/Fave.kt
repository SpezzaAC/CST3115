package com.cst3115.enterprise.groupprojectfinal

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "faves") // Define the table name
data class Fave(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val namePrice: String,
    val img: Int
)