package com.cst3115.enterprise.enterprise.assignment2

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun SettingsPage(navController: NavController) {

    var city by remember {
        mutableStateOf("")
    }

    fun saveCity(context: Context, c: String) {
        val prefs = context.getSharedPreferences("WeatherApp", Context.MODE_PRIVATE)
        prefs.edit().putString("city", c).apply()
    }

    fun getCity(context: Context): String {
        val prefs = context.getSharedPreferences("WeatherApp", Context.MODE_PRIVATE)
        return prefs.getString("city", "Ottawa")!!
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Row {
                OutlinedTextField(
                    modifier = Modifier.weight(1f),
                    value = city,
                    onValueChange = {
                        city = it
                    },
                    label = {
                        Text(text = "Enter the new city name")
                    }
                )
            }
        }

        val context = LocalContext.current

        Text(text = "Current city selection:")
        Text(text = getCity(context))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = {
                saveCity(context, city)
                navController.navigate("weatherPage")
            }) { Text("Save") }
            Button(onClick = {
                navController.navigate("weatherPage")
            }) { Text("Cancel") }
        }
    }
}