package com.cst3115.enterprise.enterprise.assignment2.api

data class WeatherModel(
    val current: Current,
    val forecast: Forecast,
    val location: Location
)