package com.cst3115.enterprise.enterprise.assignment2.api

object Constant {

    val apiKey = "215880ed65b74bbe862181853240511"
    val days = "5"
    val aqi = "no"
    val alerts = "no"

}