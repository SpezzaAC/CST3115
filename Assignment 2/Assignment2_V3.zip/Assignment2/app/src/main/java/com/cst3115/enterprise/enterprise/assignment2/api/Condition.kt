package com.cst3115.enterprise.enterprise.assignment2.api

data class Condition(
    val code: String,
    val icon: String,
    val text: String
)