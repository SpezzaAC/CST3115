package com.cst3115.enterprise.enterprise.assignment2
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import androidx.work.CoroutineWorker
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.Data
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext

class RefreshDataWorker(
    context: Context,
    params: WorkerParameters
    ) : CoroutineWorker(context, params) {

    private val weatherViewModel = WeatherViewModel()

    fun getCity(context: Context): String {
        val prefs = context.getSharedPreferences("WeatherApp", Context.MODE_PRIVATE)
        return prefs.getString("city", "Ottawa")!!
    }

    override suspend fun doWork(): Result {
        return try {
            val city = getCity(applicationContext)
            weatherViewModel.getData(city)
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}