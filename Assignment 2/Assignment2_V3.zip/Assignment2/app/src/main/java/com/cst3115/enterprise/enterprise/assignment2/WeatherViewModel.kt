package com.cst3115.enterprise.enterprise.assignment2

import android.net.Network
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cst3115.enterprise.enterprise.assignment2.api.Constant
import com.cst3115.enterprise.enterprise.assignment2.api.NetworkResponse
import com.cst3115.enterprise.enterprise.assignment2.api.RetrofitInstance
import com.cst3115.enterprise.enterprise.assignment2.api.WeatherModel
import kotlinx.coroutines.launch

class WeatherViewModel : ViewModel() {

    private val weatherApi = RetrofitInstance.weatherApi
    private val _weatherResult = MutableLiveData<NetworkResponse<WeatherModel>>()
    val weatherResult : LiveData<NetworkResponse<WeatherModel>> = _weatherResult

    fun getData(city : String){

        _weatherResult.value = NetworkResponse.Loading

        viewModelScope.launch {
            try{
                val response = weatherApi.getWeather(Constant.apiKey, city, Constant.days, Constant.aqi, Constant.alerts)
                if (response.isSuccessful){
                    response.body().let {
                        _weatherResult.value = NetworkResponse.Success(it!!)
                    }
                }else{
                    _weatherResult.value = NetworkResponse.Error("Failed to load data")
                }
            }catch (e : Exception) {
                _weatherResult.value = NetworkResponse.Error("Failed to load data")
            }
        }


    }

}